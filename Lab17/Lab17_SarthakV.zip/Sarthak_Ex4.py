#Christmas song
from Lab17.Sarthak_Ex3 import get_ordinal_number


def verse():
    n= int(input("Enter the verse day: "))
    print(f"On the {get_ordinal_number(n)} day of Christmas, i got")

    if n >= 5:
        print("Five Golden Rings,")
    if n >= 4:
        print("Four calling birds,")
    if n >= 3:
        print("Three French Hens,")
    if n >= 2:
        print("Two turtle doves")

    if n == 1:
        print("A partridge in a pear tree.")
    else:
        print("And a partridge in a pear tree.")
    print()
    
    
def main():
    for i in range(1,6):
        verse()


if __name__ == "__main__":
    main()
